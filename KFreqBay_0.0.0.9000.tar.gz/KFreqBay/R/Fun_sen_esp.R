
# Funcion para el analisis discriminante

Fun_sen_esp <- function(r2=r2, n1=n1){

  matrix3 <- matrix()
  e =NULL


  for (j in 1:(n1-1)) {
    for (i in j:(n1-1)) {

      data <- r2[,j]
      data2 <- r2[,(i+1)]

      tab1 <- table(data2, data) # Para constatar que no exista categorias faltantes y en caso trabajar con el if
      if(nrow(tab1)!=ncol(tab1)){
        conf.table <- mis_Conf_Mat(real=data,pred=data2)} #MAtriz de confusion con missing

      if(nrow(tab1)==ncol(tab1)){
        conf.table<- (confusionMatrix(as.factor(data2), as.factor(data)))} # Para el caso que las categorias sean iguales en los dos datos

      Sen <- as.matrix(round((conf.table$byClass[,1]),5))
      Esp <- as.matrix(round((conf.table$byClass[,1]),5))
      Sen_Esp <- rbind(Sen,Esp)

      matrix3 <- cbind(e,Sen_Esp)
      e=matrix3
    }

  }


  return(matrix3)
}

