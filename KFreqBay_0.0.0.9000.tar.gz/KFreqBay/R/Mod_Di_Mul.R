

# Funcion bayesiano con una distribucion Dirichlet y una multinomial

Mod_Di_Mul <- function(r2=r2,n1=n1,NC=NC,tamano.muestral=tamano.muestral,chai=chai,burni=burni,update11=update1, iter_thin=iter_thin, thin1=thin1,DIC_=DIC_){

  mensaje0 <- "You want to perform a Bayesian analysis assuming that all categories"
  mensaje00 <-"are equiprobable."
  mensaje1 <- ""
  mensaje2 <-"1= Yes"
  mensaje3 <-"2= Not"
  mensajet1 <- rbind(mensaje0,mensaje00,mensaje1,mensaje2,mensaje3)
  rownames(mensajet1) <- c("","","","","")
  colnames(mensajet1) <- ""
  print(mensajet1, quote=FALSE)

  num <- readline("Option=")
  num <- as.numeric(num)


  if (num!=2){p <- rep(1,NC)}
  if (num==2){
    p <- numeric()
    for (i in 1:NC) {
      p[i] <- readline(paste("Enter the probability of the category",i,"="))
    }
    p <- as.numeric(p)
  }

  r21 <- list()
  DIC <- numeric()
  t <- 0
  for (j in 1:(n1-1)) {
    for (i in j:(n1-1)) {
      rater1 <- r2[,j]
      rater1 <- as.numeric(rater1)
      rater2 <- r2[,(i+1)]
      rater2 <- as.numeric(rater2)
      agreement <- rater1 == rater2
      n_categories <- NC
      n_ratings <-  tamano.muestral
      prob <- p
      Model <- "model {

     # Verosimilitud

      kappa <- (p_agreement - expected_agreement) / (1 - expected_agreement)
      expected_agreement <- sum(p1 * p2)

      for(i in 1:n_ratings) {
      rater1[i] ~ dcat(p1)
      rater2[i] ~ dcat(p2)
      agreement[i] ~ dbern(p_agreement)
      }

      #  Parametros prior
      p1 ~ ddirch(alpha)
      p2 ~ dmulti(alpha,1)
      p_agreement ~ dbeta(1, 1)

      alpha <- prob
    }"

      # Ejecucion del modelo bayesiano
      Model_jags <- jags.model(file = textConnection(Model),
                               data = list(prob=prob,agreement = agreement,
                                           n_ratings = n_ratings),
                               n.chains= as.numeric(chai), n.adapt= as.numeric(burni))
      # n.adapt es el periodo de aceptacion

      update(Model_jags, as.numeric(update11))
      mcmc_sample <- coda.samples(Model_jags, variable.names="kappa", n.iter=iter_thin,thin = thin1,na.rm = TRUE)

      if (DIC_==1){
        DIC[i+t] <- round(sum(dic.samples(Model_jags,n.iter=iter_thin,thin = thin1,"pD", na.rm=TRUE)$deviance),5)
      }
      if (DIC_!=1){DIC[i+t] <- 0}

      r21[[i+t]] <- mcmc_sample
      te <-(i+t)
  }
    t <- (te-j)
}
  return(list(
    mcmc_sample1 <- r21,
    DIC <- DIC
  ))
}


