
# Funcion que permite crear una muestra multinomial con NC probabilidades

Fun_multi <- function(n=n,NC=NC,tamano.muestral=tamano.muestral,proba=proba){

  proba <- as.numeric(proba)
  m <- integer(n)
  y= 1:NC
  for(i in 1:n){
    r <- rmultinom(tamano.muestral, size = 1, prob = proba)*y
    r <- apply(r, 2, function(x) x[x != 0])
    m[i] <- sum(r)
  }
  return(list(r,m))
}
