
#' Conversion of database type string to numeric.
#'
#' @description Change categories formed by words in numerical categories, allowing to facilitate the visualization and respective calculations.
#'
#' @param r2 Name of the database previously established in software R, placing the standard Gold in the first column.
#'
#' @export


##################################################################################
# PREPARACION DE DATOS - SI SE TIENE UNA BASE DE DATOS
##################################################################################

#---------------------------------------------------------------------
#Cambio a categorias numericas

base_datos <- function(r2=r2){

  r2 <- Fun_cam_cate(r2=r2)

  le <- levels(r2[,1])
  NC <- as.numeric(length(le)) # Numero  de categorias
  tamano.muestral <- as.numeric(nrow(r2))
  n1 <- as.numeric(ncol(r2)) # numero de observadores
  num_obs <- ncol(r2) # Numero de observadores

  return(list(
    NC <- NC,
    tamano.muestral <- tamano.muestral,
    r2 <- r2,
    n1 <- n1,
    num_obs <- num_obs
  ))

}
