
# Cambio de muestra


#Cambio tamano muestral

cam_mues <- function(r2=r2,num_multi=num_multi,set_seed=set_seed,proba=Probab,accu=accu,chai=chai,burni=burni,update1=update1, iter_thin=iter_thin, thin1=thin1,models=models,DIC_=DIC_,ven_wid=ven_wid,NC=NC){

  mensaje <- Fun_men5()
  print(mensaje, quote=FALSE)
  read <- readline(prompt = "Option=")
  read <- as.numeric(read)

  if ( !(read %in% c(3,2,1) )){ message("It is not a valid number"); read<-NULL}

  else if (read == 1) {

  times <- readline(prompt = "Indicate the number of times you want to change the sample = ")
  times <- as.numeric(times)

  Repo_final_2 <- list()
  for (i in 1:times) {
    nueva_muestra <- readline(prompt = "Sample size = ")
    nueva_muestra <- as.numeric(nueva_muestra)


    tamano.muestral <- nueva_muestra
    num <- (ncol(r2)-1)


    n <- num_multi
    set.seed(set_seed)
    lista2 <- Fun_multi(n=n,NC=NC,tamano.muestral=tamano.muestral,proba=proba)
    r <- as.data.frame(lista2[[1]])
    names(r) <- "r"
    m <- lista2[[2]]
    N = num

    mal.cla <- numeric(num)
    recla <- numeric(num)
    vo <- numeric(num)
    simul.algo2 <- as.data.frame(replicate(N,r))
    for (i in 1:N) {
      mal.cla[i] <- nrow(simul.algo2)*(1-accu[i])
      recla[i] <- round(nrow(simul.algo2)/mal.cla[i])
      vo[i] <- recla[i]-1
    }

    for (j in 1:N) {
      vo1 <- vo[j]
      recla1 <- recla[j]
      mal.cla1 <- mal.cla[j]

      for (i in 1:mal.cla1) {
        if ((vo1+i+1)<=nrow(simul.algo2)){
          simul.algo2[i+vo1,j] <- as.numeric(sample(x=1:NC, size = 1,replace = TRUE) )
          vo1 = vo1+i+recla1-(i+1)}
      }
    }

    r2 <- data.frame(cbind(r,simul.algo2))
    names(r2) <- 1:(num+1)


    n1 <- as.numeric(ncol(r2))


    lis_final <- Analisis_frecue(r2=r2, n1=n1,NC=NC)
    Stat_by_clas <- Fun_sen_esp(r2=r2, n1=n1)


    list_two <- Analisis_bayes(r2=r2,n1=n1,NC=NC,tamano.muestral=tamano.muestral,lis_final=lis_final,chai=chai,burni=burni,update1=update1, iter_thin=iter_thin, thin1=thin1,models=models,Stat_by_clas=Stat_by_clas,DIC_=DIC_)
    mcmc_sample1 <- list_two[[1]]
    Repor_Gelm_Raf <- list_two[[2]] # En todas el resultado viene por lista y debe escogerse la pareja
    Repo_final <- list_two[[3]] # Reporte Total
    dev.off()
    #-------------------------------------------------------------
    # Reporte final2 en pdf

    TM <- nrow(r2)
    pdf(paste("Finalreport_",TM,".pdf"), height=11, width=ven_wid)
    grid.table(Repo_final)
    dev.off()

    Repo_final_2[[i]] <- Repo_final
  }

  }

  else if (read == 2) {Repo_final_2 <- 0}

return(Repo_final_2)
}
