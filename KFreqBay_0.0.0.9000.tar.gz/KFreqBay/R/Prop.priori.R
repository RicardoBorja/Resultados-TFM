
# Funcion para establecer las probabilidades a priori

Prop.priori <- function(){

  mensaje <- Fun_men2()
  print(mensaje, quote=FALSE)
  read <- readline(prompt = "Option=")


  if ( !(read %in% c(3,2,1) )){ message("It is not a valid number"); read<-NULL}
  else if (read == 1) {
    N <- readline("Enter the number of categories =")
    N <- as.numeric(N)
    pro <- numeric(N)
    for (i in 1:N) {
      Ncat <- readline(paste("Categories",i,"="))
      Ncat <- as.numeric(Ncat)
      pro[i] = Ncat
    }
    tamano.muestral <- sum(pro)
    proba <- pro/tamano.muestral

  }
  else if (read == 2) {
    N <- readline("Enter the number of categories=")
    N <- as.numeric(N)
    pro <- numeric(N)
    for (i in 1:N) {
      Ncat <- readline(paste("Category probability",i,"="))
      Ncat <- as.numeric(Ncat)
      pro[i] = Ncat
    }
    tamano.muestral <- readline("Enter the sample size =")
    tamano.muestral <- as.numeric(tamano.muestral)
    proba <- pro

  }
  else if (read == 3) {read <- NA}
  return(list(N,tamano.muestral,proba))
}

