
# Funcion que permite crear la clasificacion de varios observadores

Fun_clas_obs <- function(r=r,NC=NC){
  mensaje0 <- "This phase allows you to generate several observers defining the"
  mensaje00 <-"accuracy of each one in relation to the gold standard between 0 and 1"
  mensajet1 <- rbind(mensaje0,mensaje00)
  rownames(mensajet1) <- c("","")
  colnames(mensajet1) <- ""
  print(mensajet1, quote=FALSE)

  num <- readline("Enter the number of observers =")
  num <- as.numeric(num)
  N = num
  accu <- numeric()
  for (i in 1:N) {
    acc <- readline(paste("Minimal accuracy of the observer(0-1)",i,"="))
    acc <- as.numeric(acc)
    accu[i] <- acc
  }

  mal.cla <- numeric(num)
  recla <- numeric(num)
  vo <- numeric(num)
  simul.algo2 <- as.data.frame(replicate(N,r))
  for (i in 1:N) {
    mal.cla[i] <- nrow(simul.algo2)*(1-accu[i])
    recla[i] <- round(nrow(simul.algo2)/mal.cla[i])
    vo[i] <- recla[i]-1
  }

  for (j in 1:N) {
    vo1 <- vo[j]
    recla1 <- recla[j]
    mal.cla1 <- mal.cla[j]

    for (i in 1:mal.cla1) {
      if ((vo1+i+1)<=nrow(simul.algo2)){
        simul.algo2[i+vo1,j] <- as.numeric(sample(x=1:NC, size = 1,replace = TRUE) )
        vo1 = vo1+i+recla1-(i+1)}
    }
  }

  r2 <- data.frame(cbind(r,simul.algo2))
  names(r2) <- 1:(num+1)
  return(list(
    r2 <- r2,
    accu <- accu
  ))
}

