
#' Frecuentist concordance analysis
#' @description Do the Frecuentist concordance analysis.
#'
#' @param r2 Name of the database previously established in software R, placing the standard Gold in the first column.
#' @param n1 Number of observers.
#' @param NC Number of categories.
#' @export


##################################################################################
#                         ANALISIS FRECUENTISTA
##################################################################################
#------------------------------------------------------------------

Analisis_frecue <- function(r2=r2, n1=n1,NC=NC){

# ANALISIS DISCRIMINANTE

  lista3 <- Fun_ana_disc(r2=r2, n1=n1) # Calcula: Overall Statistics y Statistics by Class

# Impresion de datos

  lis_final <-  Fun_imp_trad(r2=r2, lista3=lista3, n1=n1) # Entrega de resultados

  return(lis_final <- lis_final)

}
