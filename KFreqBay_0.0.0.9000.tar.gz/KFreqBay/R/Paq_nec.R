# Instalacion y activacion de paquetes necesarios

Paq_nec <- function(){
  if(!require("fBasics")) install.packages("fBasics")
  if(!require("psych")) install.packages("psych")
  if(!require("lattice")) install.packages ( "lattice" )
  if(!require("ggplot2")) install.packages ( "ggplot2" )
  if(!require("caret")) install.packages ( "caret" )
  if(!require("coda")) install.packages ( "coda" )
  if(!require("rjags")) install.packages ( "rjags" )
  if(!require("HDInterval")) install.packages ( "HDInterval" )
  if(!require("BEST")) install.packages ( "BEST" )
  if(!require("boot")) install.packages ( "boot" )
  if(!require("DMwR")) install.packages ( "DMwR" )
  if(!require("REdaS")) install.packages ( "REdaS" )

  require("fBasics")
  require("psych")
  require ("lattice")
  require("ggplot2")
  require ("caret")
  require("coda")
  require("rjags")
  require("HDInterval")
  require("BEST")
  require("boot")
  require("DMwR")
  require("REdaS")
  require("gridExtra")
  graphics.off()
}

