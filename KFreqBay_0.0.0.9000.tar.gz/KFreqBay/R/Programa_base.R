#' Frequentist - Bayesian concordance analysis of dichotomous and political data.
#' @description allows a robust and effective analysis of concordance, applicable to data with dichotomous and polytomous variables using the frequentist and Bayesian method using MCMC, either creating a standard Gold and classifiers with a multinomial distribution in fictitious form or through a set of pre-established data.
#'
#' The function programmed for this package is K_Freq_Bay () and has the following default values:
#'
#' K_Freq_Bay(data=FALSE,setseed=1234,num_mult=1000,burn_in=10000,chains=2,updat=1000,thin_=1,iter_thin_=20000,models=1,DIC_=0)
#'
#' @param data Specify the name of the database file of type "dataframe" to be analyzed previously loaded in R, with the standard Gold located in the first column. In the illustrative case you want to create a standard Gold and fictitious classifiers with a multinomial distribution data=FALSE.
#' @param setseed Seed fixed only for the case data = FALSE in order to obtain reproducible and comparable multinomial data.
#' @param num_mult Number of times that multinomial random data will be simulated in the case data = FALSE.
#' @param burn_in Number of values discarded due to the heating phase in the Bayesian analysis by MCMC.
#' @param chains Number of Markov chains to simulate.
#' @param updat Number of times that the proposed Bayesian model will be simulated.
#' @param thin_ Number of data selected in each delay r in order that the sample does not have a linear correlation.
#' @param iter_thin_ Number of iterations choosing the defined thin.
#' @param models Bayesian models for concordance analysis: 1 = Dirichlet - Dirichlet, 2 = Dirichlet - Multinomial, 3 = Beta - Beta.
#' @param DIC_ Predictive capacity of the model. If the value is 0 the calculation is omitted, in the case of assigning 1 the value will be obtained for all the possibilities of pairs, for which the user will understand that the execution time will be greater.
#' @return
#'
#' As a result, we obtain pdf files located in the directory preset by the user:
#'
#' * Frequency graphs - number of categories for each observer.
#' * Kappa frequentist density chart VS kappa Bayesian (by specific pair of observers or all the possibilities of pairs).
#' * Diagram of autocorrelation and convergence diagnosis of Markov chains (by specific pair of observers or all the possibilities of pairs).
#' * Final report of general statistics of the frequentist and Bayesian method.
#'
#' In list format the function returns:
#'
#'  1. Report of the convergence analysis and stationarity test of Gelman Rubin, Raftery Lewis and Cramer Von Mises.
#'  2. Final report of the overall statistics.
#'  3. Final report in case of sample size changes.
#'
#' @examples
#'
#' A text will be printed on the console giving instructions for the correct development of the process.
#' You only have to choose the options to be agreed and specify the probabilities in specific cases.
#'
#' In an educational way you can work with the default values: generating the standard Gold through a multinomial distribution according to the desired parameters and attaching as many observers as you wish, limiting a minimum precision in each one of them.
#'
#' The graphs of exit could be chosen by the user in case of having interest only a pair of specific observers or with all the possible pairs.
#'
#' n the graphs of Gelman Rubin and autocorrelation I want to choose a pair should follow the present logic:
#'
#' Por ejemplo para el caso de 3 observadores (tambien cuenta el Gold estandar)
#' Observer 1-2 = pair 1
#'          1-3 = pair 2
#'          2-3 = pair 3
#'
#'@export



##################################################################################
#                            PROGRAMA BASE
##################################################################################

K_Freq_Bay <- function(data=FALSE,setseed=1234,num_mult=1000,burn_in=10000,chains=2,updat=1000,thin_=1,iter_thin_=20000,models=1,DIC_=0){

  set_seed <- as.numeric(setseed) # Seet.seed fijado para la multinomial
  num_multi <- as.numeric(num_mult) # numero de bucles para generar la multinomial
  models <- as.numeric(models) # Tamano de la ventana de salida pdf del reporte
  burni <- as.numeric(burn_in) # Burnin o calentamiento
  chai <- as.numeric(chains) # Numero de cadenas
  update1 <- as.numeric(updat) #Numero de repeticiones
  thin1 <- as.numeric(thin_) #Intervalos para muestreo
  iter_thin <- as.numeric(iter_thin_) # iteraciones para thin
  DIC_=as.numeric(DIC_)

#-------------------------------------------------------------
# INSTALACION DE PAQUETES NECESARIOS
  Paq_nec()

  print(Fun_men1(), quote=FALSE)

#-------------------------------------------------------------
# CREACION DE DATOS MULTINOMIALES

  r2 <- data
  L <- as.numeric(length(r2))

  if (L==1 ){
    list_one <- muestra_categori(set_seed=set_seed,num_multi=num_multi)
    NC <- list_one[[1]]
    tamano.muestral <- list_one[[2]]
    Probab <- list_one[[3]]
    r2 <- list_one[[4]]
    n1 <- list_one[[5]]
    num_obs <- list_one[[6]]
    accu <- list_one[[7]]
  }

#-------------------------------------------------------------
# PREPARACION DE DATOS - CAMBIO A CATEGORIAS NUMERICAS

  if (L!=1 ){
    list_one <- base_datos(r2=r2)
    NC <- list_one[[1]]
    tamano.muestral <- list_one[[2]]
    r2 <- list_one[[3]]
    Numcol <- ncol(r2)
      for (i in 1:Numcol) {
        r2[,i] <- as.factor(r2[,i])
      }

    n1 <- list_one[[4]]
    num_obs <- list_one[[5]]

  }

#-------------------------------------------------------------
# TRATAMIENTO DE MISSING
  r2 <- knnImputation(r2,k=5)
  NC <- as.numeric(length(as.numeric(levels(as.factor(r2[,1])))))
#-------------------------------------------------------------
# CARACTERISTICAS

  Fun_carac(r2=r2,data=data,NC=NC,L=L,tamano.muestral=tamano.muestral)


#-------------------------------------------------------------
# ANALISIS FRECUENTISTA

  lis_final <- Analisis_frecue(r2=r2, n1=n1,NC=NC)
  Stat_by_clas <- Fun_sen_esp(r2=r2, n1=n1)

#-------------------------------------------------------------
# ANALISIS BAYESIANO


  list_two <- Analisis_bayes(r2=r2,n1=n1,NC=NC,tamano.muestral=tamano.muestral,lis_final=lis_final,chai=chai,burni=burni,update1=update1, iter_thin=iter_thin, thin1=thin1,models=models,Stat_by_clas=Stat_by_clas,DIC_=DIC_)

  mcmc_sample1 <- list_two[[1]]
  Repor_Gelm_Raf <- list_two[[2]] # En todas el resultado viene por lista y debe escogerse la pareja
  Repo_final <- list_two[[3]] # Reporte Total

  dev.off()

#-------------------------------------------------------------
# REPORTE FINAL EN PDF
  ven_wid <- ((as.numeric(num_obs))*3)+6
  TM <- nrow(r2)
  pdf(paste("Finalreport_",TM,".pdf"), height=11, width=ven_wid)
  grid.table(Repo_final)
  dev.off()



#------------------------------------------------------------
# CAMBIO DE MUESTRA

  Repo_final_2 <-0

  if (L==1){

    Repo_final_2 <- cam_mues(r2=r2,num_multi=num_multi,set_seed=set_seed,proba=Probab,accu=accu,chai=chai,burni=burni,update1=update1, iter_thin=iter_thin, thin1=thin1,models=models,DIC_=DIC_,ven_wid=ven_wid,NC=NC)
  }


#------------------------------------------------------------
#-------------------------------------------------------------
# IMPRESION DE MENSAJE FINAL EN LA CONSOLA
  mensaje <- Fun_men6()
  print(mensaje, quote=FALSE)

# DATOS DEVUELTOS
  return(list(
    Report_Gelm_Raf_Von <- Repor_Gelm_Raf,
    Report_final <- Repo_final,
    Final_report_2 <- Repo_final_2
  ))
}
