
# Funcion para obtener graficas de caracteristicas

Fun_carac <- function(r2=r2,data=data,NC=NC,L=L,tamano.muestral=tamano.muestral){
  # Grafica para observar las caracteristicas de los datos
  num_col <- as.numeric(ncol(r2))

   if (L==1){
    nombres <- dimnames(r2)[[2]]
    le <- as.character(1:NC)
  }
  if (L!=1){
    nombres <- dimnames(data)[[2]]
    le <- levels(as.factor(data[,1]))
  }

  Freq_int <- list()
  for (i in 1:num_col) {
    pdf(paste("Features_obs",i,"_",tamano.muestral,".pdf"))
    barplot(freqCI(as.factor(r2[,i])), col = c("lightgreen", "aquamarine", "burlywood1", "coral1"),
            xlab="Categories",ylab="Percentage", main = paste("Frequencies with confidence intervals - ",nombres[i]))
    legend("topleft", le,col = c("lightgreen", "aquamarine", "burlywood1", "coral1"),
           lty= 1,cex = 0.5)

    if (L==1){
      Freq_int[[i]] <- freqCI(r2[,i])
    }
    if (L!=1){
      Freq_int[[i]] <- freqCI(data[,i])
    }
    dev.off()
  }

}

