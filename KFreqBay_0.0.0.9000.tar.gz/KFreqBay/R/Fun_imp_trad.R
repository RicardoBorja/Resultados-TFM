

# Funcion para consultar que imprimir

Fun_imp_trad <- function(r2=r2, lista3=lista3, n1=n1){
  sta_over <- lista3


  lis_final <- as.data.frame(sta_over) # escoje las columnas para formar los pares solucion
  lis_final <- round(lis_final,6)
  lis_final <- as.data.frame(lis_final)
  name <- character()

  t <- 0
  for (j in 1:(n1-1)) {
    for (i in j:(n1-1)) {
      name[i+t] <- paste(as.character(j),"-",as.character(i+1))
      te <- (i+t)
    }
      t <- (te-j)
  }
  names(lis_final) <- name
  return(lis_final)
}



