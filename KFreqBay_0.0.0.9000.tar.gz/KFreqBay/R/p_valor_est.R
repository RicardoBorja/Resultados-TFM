
# p-valor de estacionariedad


p_valor_est <- function(y=y,n1=n1,lis_final=lis_final,chai=chai){
  lis_an <- data.frame()
  cad1 <- numeric()
  cad2 <- numeric()
  num <-as.numeric(length(lis_final))

    for (i in 1:num) {
      x <- y[[i]] # Definiendo datos

      # Test de estacionariedad, utiliza la estadistica de Cramer Von Mises
      c <-heidel.diag(x)

      cad1[i] <- round(c[[1]][3],6)
      cad2[i] <- round(c[[2]][3],6)
      if (chai>=3){cad3[i] <- round(c[[2]][3],6)}
      if (chai>=4){cad4[i] <- round(c[[2]][3],6)}
      if (chai>=5){cad5[i] <- round(c[[2]][3],6)}

    }

  if (chai==2){lis_an <- as.data.frame(rbind(cad1,cad2))}
  if (chai==3){lis_an <- as.data.frame(rbind(cad1,cad2,cad3))}
  if (chai==4){lis_an <- as.data.frame(rbind(cad1,cad2,cad3,cad4))}
  if (chai==5){lis_an <- as.data.frame(rbind(cad1,cad2,cad3,cad4,cad5))}
  name <- character()
  t <- 0
  for (j in 1:(n1-1)) {
    for (i in j:(n1-1)) {
      name[i+t] <- paste("p_val ",as.character(j),"-",as.character(i+1))
      te <- (i+t)
    }
    t <- (te-j)
  }
  names(lis_an) <- name
  return(lis_an)
}
