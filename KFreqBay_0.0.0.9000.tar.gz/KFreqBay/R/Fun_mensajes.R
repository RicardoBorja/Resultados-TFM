

Fun_men1 <- function(){
  mensaje0 <- "You must load the database to R locating the gold"
  mensaje00 <-"standard in the first column, the file should be"
  mensaje1 <- "data frame. "
  mensajet1 <- rbind(mensaje0,mensaje00,mensaje1)
  rownames(mensajet1) <- c("","","")
  colnames(mensajet1) <- ""
  return(mensajet1)
}

Fun_men2 <- function(){
  mensaje0 <- "Choose the way you want to create the sample (Example: Option= 1)."
  mensaje00 <- ""
  mensaje1 <- paste("1 =", "Entering the size of each category")
  mensaje2 <- paste("2 =", "Enter the probabilities by categories")
  mensaje3 <- paste("3 =", "Go out")
  mensajet1 <- rbind(mensaje0,mensaje00,mensaje1,mensaje2,mensaje3)
  rownames(mensajet1) <- c("","","","","")
  colnames(mensajet1) <- ""
  return(mensajet1)
}



Fun_men3 <- function(){
  mensaje0 <- "Choose what graph you want to obtain."
  mensaje00 <- ""
  mensaje1 <- paste("1 =", "Kappa density graphics between 2 observers")
  mensaje2 <- paste("2 =", "Graphics Kappa density of all possible pairs of observers")
  mensaje3 <- paste("3 =", "Go out")
  mensajet1 <- rbind(mensaje0,mensaje00,mensaje1,mensaje2,mensaje3)
  rownames(mensajet1) <- c("","","","","")
  colnames(mensajet1) <- ""
  return(mensajet1)
}


Fun_men4 <- function(){
  mensaje0 <- "From the chosen option you will obtain Diagnosis of"
  mensaje00 <-"convergence of Gelman Rubin, by Raftery-Lewis and "
  mensaje1 <- "stationarity test of Cramer Von Mises."
  mensaje2 <- ""
  mensaje3 <- paste("1 =", "Analysis of specific observer pair")
  mensaje4 <- paste("2 =", "Analysis of all possible pairs of observers")
  mensaje5 <- paste("3 =", "Go out")
  mensajet1 <- rbind(mensaje0,mensaje00,mensaje1,mensaje2,mensaje3,mensaje4,mensaje5)
  rownames(mensajet1) <- c("","","","","","","")
  colnames(mensajet1) <- ""
  return(mensajet1)
}

Fun_men5 <- function(){
  mensaje0 <- "You want to change the sample size and get the same results"
  mensaje00 <- ""
  mensaje1 <- ("1 = Yes")
  mensaje2 <- ("2 = Not")
  mensajet1 <- rbind(mensaje0,mensaje00,mensaje1,mensaje2)
  rownames(mensajet1) <- c("","","","")
  colnames(mensajet1) <- ""
  return(mensajet1)
}

Fun_men6 <- function(){
  mensaje0 <- "Process completed,the pdf files were successfully created in the established working directory."
  mensaje1 <- " "
  mensaje2 <- "The function generates a list with 3 elements:"
  mensaje3 <- "1:Convergence report and stationarity test of Gelam Rubin, Raftery Lewis and Cramer Von Mises. "
  mensaje4 <- "2:Final report of overall statistics of the frequentist and Bayesian method. "
  mensaje5 <- "3:Final reports in case of changes in sample size."
  mensajet1 <- rbind(mensaje0,mensaje1,mensaje2,mensaje3,mensaje4,mensaje5)
  rownames(mensajet1) <- c("","","","","","")
  colnames(mensajet1) <- ""
  return(mensajet1)
}
