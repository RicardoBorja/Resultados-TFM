#' Bayesian concordance analysis by MCMC
#'
#' @description Depending on the model chosen, the kappa parameter is estimated, the density graph is contrasted with the frequentist method, a convergence analysis and the stationarity test of the Markov chains. With data plotted in the working directory in pdf format.
#'
#' @param r2 data-set matrix with data containing the metagenomic frequencies (rows: OTUs, columns: samples)
#' @param n1 Number of observers.
#' @param NC Number of categories.
#' @param tamano.muestral Sample size of the data
#' @param list_final Overall frecuentist statistics.
#' @param chai Number of Markov chains to simulate.
#' @param burni Number of values discarded due to the heating phase in the Bayesian analysis by MCMC.
#' @param update1 Number of times that the proposed Bayesian model will be simulated.
#' @param ite_thin Number of iterations choosing the defined thin.
#' @param thin1 Number of data selected in each delay r in order that the sample does not have a linear correlation.
#' @param models Bayesian models for concordance analysis: 1 = Dirichlet - Dirichlet, 2 = Dirichlet - Multinomial, 3 = Beta - Beta.
#' @param Stat_by_clas Overall statistics by class.
#' @param DIC_ Predictive capacity of the model. If the value is 0 the calculation is omitted, in the case of assigning 1 the value will be obtained for all the possibilities of pairs, for which the user will understand that the execution time will be greater.
#' @export

##################################################################################
#                            ANALISIS BAYESIANO
##################################################################################

# Modelo de 2 Dirichlet con todos los pares posibles
Analisis_bayes <- function(r2=r2,n1=n1,NC=NC,tamano.muestral=tamano.muestral,lis_final=lis_final,chai=chai,burni=burni,update1=update1, iter_thin=iter_thin, thin1=thin1,models=models,Stat_by_clas=Stat_by_clas,DIC_=DIC_){

  models <- as.numeric(models)

  if (models==1){
  Modelo1 <- Mod_Di_Di(r2=r2,n1=n1,NC=NC,tamano.muestral=tamano.muestral,chai=chai,burni=burni,update11=update1, iter_thin=iter_thin, thin1=thin1,DIC_=DIC_)
  mcmc_sample1 <- Modelo1[[1]]
  DIC <- Modelo1[[2]]
  }

  if (models==2){
    Modelo1 <- Mod_Di_Mul(r2=r2,n1=n1,NC=NC,tamano.muestral=tamano.muestral,chai=chai,burni=burni,update11=update1, iter_thin=iter_thin, thin1=thin1,DIC_=DIC_)
    mcmc_sample1 <- Modelo1[[1]]
    DIC <- Modelo1[[2]]
  }

  if (models==3){
    Modelo1 <- Mod_Be_Be(r2=r2,n1=n1,NC=NC,tamano.muestral=tamano.muestral,chai=chai,burni=burni,update11=update1, iter_thin=iter_thin, thin1=thin1,DIC_=DIC_)
    mcmc_sample1 <- Modelo1[[1]]
    DIC <- Modelo1[[2]]
  }
#---------------------------------------------------------------
# Graficas Kappa frecuentista VS Kappa Bayesiano - Grafica n?mero de iteraciones Kappa

  Fungraf_frec_bay(r2=r2,n1=n1,tamano.muestral=tamano.muestral,mcmc_sample1=mcmc_sample1)
# En la traza se observa que a trayectoria de la cadena es consistente a lo largo del tiempo

#----------------------------------------------------------------
# Analisis de convergencia , estacionariedad e independencia
# Gelman Rubin - Diagnostico de Raftery-Lewis - Cramer Von Mises

  y <- mcmc_sample1
  Repor_Gelm_Raf <- Fun_Gelm_Raft(y=y,lis_final=lis_final,tamano.muestral=tamano.muestral)

#-----------------------------------------------------------------
# Test de estacionariedad, utiliza la estadistica de Cramer Von Mises
  p_valor <- p_valor_est(y=y,n1=n1,lis_final=lis_final,chai=chai)


#-----------------------------------------------------------------
# Reporte final de datos  Bayesianos y Totales

  Rep_final <- Repor_final(lis_final=lis_final, mcmc_sample1=mcmc_sample1,p_valor=p_valor,DIC=DIC,Stat_by_clas=Stat_by_clas,NC=NC)


#---------------------------------------------------------------------------


  return(list(
    mcmc_sample1 <- mcmc_sample1,
    Repor_Gelm_Raf <- Repor_Gelm_Raf,
    Rep_final <- Rep_final
  ))

}
