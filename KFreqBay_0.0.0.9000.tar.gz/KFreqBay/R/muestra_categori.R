
#' Generation of standard Gold and multinomial observers.
#'
#' @description Generation of the standard Gold and observers through a random sample of dichotomous or polytomous categories based on a multinomial distribution.
#' @param set_seed Seed fixed only for the case data = FALSE in order to obtain reproducible and comparable multinomial data.
#' @param num_multi Number of times that multinomial random data will be simulated in the case data = FALSE.
#'
#' @export

##################################################################################
# GENERACION DE MUESTRA  CATEGORICA MULTINOMIAL
##################################################################################
muestra_categori <- function(set_seed=set_seed,num_multi=num_multi){

  set_seed <- as.numeric(set_seed)
  num_multi <- as.numeric(num_multi)

#---------------------------------------------------------------------
#          PROCESO DE CARGA DE INFORMACION

  lista <- Prop.priori()
  NC <- lista[[1]] # numero de categorias
  tamano.muestral <- round((lista[[2]]),0)
  proba <- lista[[3]] # probabilidad por cada categoria
#---------------------------------------------------------------------

  n <- num_multi  # numero de bucles para crear la multinomial
  set.seed(set_seed) # En el caso que se desee que sea reproducible
  lista2 <- Fun_multi(n=n,NC=NC,tamano.muestral=tamano.muestral,proba=proba) # Funcion para crear una muestra multinomial
  r <- as.data.frame(lista2[[1]]) # muestra multinomial
  names(r) <- "r"

#---------------------------------------------------------------------

#               CREAR OBSERVADORES OBSERVADORES

  obser <- Fun_clas_obs(r=r,NC=NC) # Me entrega la clase r multinomial con varios observadores y precisi?n minima colocada
  r2 <- obser[[1]]
  accu <- obser[[2]]
  n1 <- as.numeric(ncol(r2)) # numero de datos
  num_obs <- ncol(r2)
#--------------------------------------------------------------------

  return(list(
    NC <- NC,
    tamano.muestral <- tamano.muestral,
    proba <- proba,
    r2 <- r2,
    n1 <- n1,
    num_obs <- num_obs,
    accu <- accu
  ))

}
