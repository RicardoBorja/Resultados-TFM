# Funcion Gelman Rubin y Raft y von mises

Fun_Gelm_Raft <- function(y=y,lis_final=lis_final,tamano.muestral=tamano.muestral){

  mensaje <- Fun_men4()
  print(mensaje, quote=FALSE)
  read <- readline(prompt = "Option=")

  if ( !(read %in% c(3,2,1) )){ message("It is not a valid number"); read<-NULL}

  else if (read == 1) {
    par <- readline(prompt = "Enter the partner you want to analyze=")
    par <- as.numeric(par)

    num <-as.numeric(length(lis_final))

    x <- y[[par]] # Definiendo datos


    pdf(paste("Gelm_Raft_vom",par,"-",tamano.muestral,".pdf"))
    s <- acfplot(x, main = "Autocorrelation graph ", ylab = "Autocorrelacion", xlab = paste("Lag - pair ",par,"-","TM:",tamano.muestral)) # Grafica de autocorrelacion Ho = correlaci?n
    plot(s)

    gelman.plot(x, bin.width = 10, max.bins = 100,
                  confidence = 0.95, transform = FALSE, autoburnin=TRUE, xlab = paste("Last iteration -pair ",par,"-","TM:",tamano.muestral))
    dev.off()

    # Diagnostico de convergencia de Gelman Rubin
    a <- gelman.diag(x, confidence = 0.95, transform=FALSE, autoburnin=TRUE,
                       multivariate=TRUE)

    # Diagnostico de Raftery-Lewis
    b <- raftery.diag(x, q=0.025, r=0.005, s=0.95, converge.eps=0.001)

    # Test de estacionariedad, utiliza la estadistica de Cramer Von Mises
    c <-heidel.diag(x)

    #Resultados
    re1 <- list(
    Raftery_Lewis = b[[1]],
    Cramer_Von_Mises = c[[1]])
    re2 <- list(
    Raftery_Lewis =b[[2]],
    Cramer_Von_Mises =c[[2]])

    lis_ana <- list(
        Gel_Rub = a,
        cadena1 = re1,
        cadena2 = re2)
  }


  else if (read == 2) {
    lis_ana <- list()
    num <-as.numeric(length(lis_final))

     for (i in 1:num) {
      x <- y[[i]] # Definiendo datos


      pdf(paste("Gelm_Raft_vom",i,"_",tamano.muestral,".pdf"))
      s <- acfplot(x, main = "Autocorrelation graph", ylab = "Autocorrelation", xlab = paste("Lag - pair ",i,"-","TM:",tamano.muestral)) # Grafica de autocorrelacion Ho = correlaci?n
      plot(s)

      gelman.plot(x, bin.width = 10, max.bins = 100,
                confidence = 0.95, transform = FALSE, autoburnin=TRUE, xlab = paste("Last iteration -pair ",i,"-","TM:",tamano.muestral))
      dev.off()


      # Diagnostico de convergencia de Gelman Rubin
      a <- gelman.diag(x, confidence = 0.95, transform=FALSE, autoburnin=TRUE,
            multivariate=TRUE)

      # Diagnostico de Raftery-Lewis
      b <- raftery.diag(x, q=0.025, r=0.005, s=0.95, converge.eps=0.001)

      # Test de estacionariedad, utiliza la estadistica de Cramer Von Mises
      c <-heidel.diag(x)

      #Resultados
      re1 <- list(
        Raftery_Lewis = b[[1]],
        Cramer_Von_Mises = c[[1]])
      re2 <- list(
        Raftery_Lewis =b[[2]],
        Cramer_Von_Mises =c[[2]])


      lis_ana[[i]] <- list(
                    Gel_Rub = a,
                    cadena1 = re1,
                    cadena2 = re2)
    }
  }
  return(lis_ana)
}
