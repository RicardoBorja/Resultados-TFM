

# Cambio a categorias numericas

Fun_cam_cate <- function(r2=r2){
  # Caracteristicas
  le <- levels(r2[,1])
  num_le <- length(le)
  cam <- as.character(1:num_le)
  num_col <- as.numeric(ncol(r2))
  # Cambio a categorias numericas
  for (i in 1:num_col) {
    levels(r2[,i]) <- cam
  }
  return(r2)
}




