
# Funcion para el analisis discriminante

Fun_ana_disc <- function(r2=r2, n1=n1){
  matrix2 <- matrix() # guarda datos de Overall Statistics y statistics by class
  kap <- c("unweighted KappaLower", "Kappa" ,"unweighted KappaUpper")
  c =NULL

  for (j in 1:(n1-1)) {
    for (i in j:(n1-1)) {

      data <- r2[,j]
      data2 <- r2[,(i+1)]

      tab1 <- table(data2, data) # Para constatar que no exista categorias faltantes y en caso trabajar con el if
      if(nrow(tab1)!=ncol(tab1)){
        conf.table <- mis_Conf_Mat(real=data,pred=data2)} #MAtriz de confusion con missing

      if(nrow(tab1)==ncol(tab1)){
        conf.table<- (confusionMatrix(as.factor(data2), as.factor(data)))} # Para el caso que las categorias sean iguales en los dos datos

         d <-  as.matrix(conf.table$overall)[-2,]
         d <- as.matrix(d)

         g <- round((as.matrix(cohen.kappa(cbind(data, data2), alpha=0.05)$confid)[1,]),6)
         names(g) <- kap
         g <- t(t(g))
         d <- rbind(d,g)
         matrix2 <- cbind(c,d)
         c=matrix2

    }

  }


return(matrix2)
}

