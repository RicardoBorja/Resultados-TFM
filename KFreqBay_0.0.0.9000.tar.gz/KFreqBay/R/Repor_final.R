

Repor_final <- function(lis_final=lis_final, mcmc_sample1=mcmc_sample1,p_valor=p_valor,DIC=DIC,Stat_by_clas=Stat_by_clas,NC=NC){
  name1 <- c("Bayesian KappaLower","Bayesian Kappa","Bayesian KappaUpper","Skewness BayesianKappa","Kurtosis BayesianKappa")

  num_pos <- as.numeric(length(lis_final)) # Numero de posibilidades de parejas
  Repor <- matrix()
  N1 <- NULL
  d1 <- character()
  d2 <- character()

  for (i in 1:num_pos) {

    x <- mcmc_sample1[[i]]
    bas <- basicStats(x)
    r <- rownames(bas)[15:16]
    bas <- bas[15:16,]
    names(bas) <- r
    bas <- as.data.frame(bas)
    names(bas) <- paste("Bayesian Report",i)
    t <- as.data.frame(summary(mcmc_sample1[[i]])$quantiles)
    bas <- as.matrix(round(rbind(t[1,],t[3,],t[5,],bas),6))
    Repor <- cbind(N1,bas)
    N1 <- Repor
    d1[i] <- ""
    d2[i] <- ""
  }

  rownames(Repor) <- name1
  li <- as.matrix(lis_final)
  p_valor <- as.matrix(p_valor)
  Stat_by_clas <- as.matrix(Stat_by_clas)
  Stat1 <- Stat_by_clas[1:NC,]
  Stat1 <- rbind(d1,Stat1)
  row.names(Stat1)[1] <- ("Sensitivity - Frecuentista")
  Stat2 <- Stat_by_clas[(NC+1):(NC*2),]
  Stat2 <- rbind(d1,Stat2)
  row.names(Stat2)[1] <- ("Especificity - Frecuentista")

  Rep_Freq_Bay <- rbind(d1,li,d2,d2,Repor,DIC,d2,p_valor,Stat1,Stat2)
  row.names(Rep_Freq_Bay)[1] <- ("Frecuentista report")
  row.names(Rep_Freq_Bay)[11] <- ""
  row.names(Rep_Freq_Bay)[12] <- "Bayesian report"
  row.names(Rep_Freq_Bay)[18] <- "DIC"
  row.names(Rep_Freq_Bay)[19] <- "Stationarity p-value"

  return(Reporte_Total = Rep_Freq_Bay)
}
