


Fungraf_frec_bay <- function(r2=r2,n1=n1,tamano.muestral=tamano.muestral,mcmc_sample1=mcmc_sample1){


  mensaje <- Fun_men3()
  print(mensaje, quote=FALSE)
  read <- readline(prompt = "Option=")

  if ( !(read %in% c(3,2,1) )){ message("It is not a valid number"); read<-NULL}

  else if (read == 1) {

    co11 <- readline("Enter the first column to be analyzed=")
    co11 <- as.numeric(co11)

    co22 <- readline("Enter the second column to be analyzed=")
    co22 <- as.numeric(co22)

    data <- as.numeric(r2[,co11]) # Se crean los archivos a graficar
    data2 <- as.numeric(r2[,co22])

    x <- cbind(data, data2) # defino la variable
    # La sigueinte funcion busca un kappa para cada fila
    ck.boot <-function(x,s=1:nrow(x)) {cohen.kappa(x[s,])$kappa} # se define la funcion estadistica que en este caso es determinar kappa
    ckb <- boot(x,ck.boot,R=100) # Genero R replicas Bootstrap con los datos y el estadistico
    y <- ckb$t

    # Me da el numero interno que debo escoger en la lista de la kappa posteriori
    t <- 0
    for (i in 1:n1) {
      if ((co11==i)){  # ojo revisar solo me da si se escoje en orden primero el menor
        nu <- t + abs(co22-co11)
      }
      t <- t+3
      if (i==2){
        t<- t-1
      }
    }

    z <- as.matrix(mcmc_sample1[[nu]])

    a <- min(y,z)
    b <- max(y,z)
    c <- max(c(max((density(y))$y),max((density(z))$y)))


    par(mfrow = c(2,1))
    pdf(paste("Density_kapp_",tamano.muestral,".pdf"))
    plot(density(y), col="blue", main=paste("Kappa frequentist VS kappa bayesian",co11,"-",co22),xlab=paste("Kappa - ","TM:",tamano.muestral),ylab="Density",lwd=2, xlim=c(a,b),ylim=c(0,c))
    lines(density(z), col="red",lwd=2)
    legend("topright", c("K Frequentist", "K Bayesian"),
         lty = 1,col = c("blue", "red"), cex = 1)

    plot(mcmc_sample1[[1]],xlab=paste("kappa Bayesian",co11,"-",co22,"-","TM:",tamano.muestral))
    dev.off()
  }

  else if (read == 2) {
    t = 0
    #r22 <- as.list(r2)  # creo cada par de datos
    for (j in 1:(n1-1)) {
      for (i in j:(n1-1)) {
        data <- as.numeric(r2[,j])
        data2 <- as.numeric(r2[,(i+1)])
        x <- cbind(data, data2) # defino la variable

        # La sigueinte funcion busca un kappa para cada fila
        ck.boot <-function(x,s=1:nrow(x)) {cohen.kappa(x[s,])$kappa} # se define la funcion estadistica que en este caso es determinar kappa
        ckb <- boot(x,ck.boot,R=100) # Genero R replicas Bootstrap con los datos y el estadistico
        y <- ckb$t

        # Me da el numero interno que debo escoger en la lista de la kappa posteriori

        z <- as.matrix(mcmc_sample1[[i+t]])


        a <- min(y,z)
        b <- max(y,z)
        c <- max(c(max((density(y))$y),max((density(z))$y)))
        name <- paste(as.character(j),"-",as.character(i+1))

        par(mfrow = c(2,1))
        pdf(paste("Density_kapp_",j,(i+1),"_",tamano.muestral,".pdf"))

        plot(density(y), col="blue", main=paste("kappa frequentist VS kappa bayesian",name),xlab=paste("Kappa - ","TM:",tamano.muestral),ylab="Density",lwd=2, xlim=c(a,b),ylim=c(0,c))
        lines(density(z), col="red",lwd=2)
        legend("topright", c("K frequentist", "K Bayesian"),
           lty = 1,col = c("blue", "red"), cex = 1)

        plot(mcmc_sample1[[i+t]],xlab=paste("kappa Bayesian ", name,"-","TM:",tamano.muestral))
        dev.off()

        te <- t+i
      }
      t <- (te-j)
    }
  }

  else if (read == 3) {read <- NULL}

}

